'''
Created on 23 Sep 2019

@author: tim
'''
import main.functions as functions


# from parameters import *
# from gui_functions import *

# gui_functions.test_run_model()

# gui_functions.test_process_arff_folder()

#gui_functions.test_play_clip()

# test_create_arff_file_header()
# 
# test_append_data_to_arff_file()

# test_extract_melspectrogram()

# test_fingerprint()

# test_featureExtraction()

# test_pyAudioAnalysisFeatureExtraction()

# test_librosaFeatureExtraction()

# functions.test_insert_onset_into_database()

# functions.create_onsets()

# functions.test_get_onsets_stored_locally()

# functions.create_focused_mel_spectrogram_jps_using_onset_pairs()

#functions.test_get_unique_recording_ids_that_have_been_tagged_with_this_tag_stored_locally()

# functions.test_create_onsets_with_null_existing_tag()

# functions.test_create_onsets_with_existing_tag()

# functions.test_play_clip()

# functions.test_update_model_run_result()

# functions.test_get_model_run_result()

# functions.test_get_arff_for_single_focused_mel_spectrogram()

# functions.update_morepork_name()

# functions.create_spectrogram_jpg_files_for_next_model_run()

# functions.test_create_arff_file_for_weka_image_filter_input()
functions.create_arff_file_for_weka_image_filter_input()

# functions.test_run_model()

# functions.analyse_onsets_using_weka_model()

# functions.update_latest_model_run_results_with_previous_confirmed()


